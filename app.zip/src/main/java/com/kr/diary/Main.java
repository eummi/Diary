package com.kr.diary;

public class Main {
}
