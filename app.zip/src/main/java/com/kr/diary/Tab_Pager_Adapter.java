package com.kr.diary;

import android.support.design.widget.TabItem;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

/**
 * Created by aristata on 2016-07-20.
 */
public class Tab_Pager_Adapter extends FragmentStatePagerAdapter {
    private int tabCount;

    //activity_main 전역변수
    public static TabItem tabItem1;
    public static TabItem tabItem2;
    public static TabItem tabItem3;
    public static TabItem tabItem4;

    public Tab_Pager_Adapter(FragmentManager fm, int tabCount) {
        super(fm);
        this.tabCount = tabCount;
    }
    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                MainActivity.Main main = new MainActivity.Main();
                return main;
            case 1:
                MainActivity.Schedule schedule= new MainActivity.Schedule();
                return schedule;
            case 2:
                MainActivity.Diary_Write diary_write = new MainActivity.Diary_Write();
                return diary_write;
            case 3:
                MainActivity.DiaryPage diarypage= new MainActivity.DiaryPage();
                return diarypage;
            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        return tabCount;
    }
}
