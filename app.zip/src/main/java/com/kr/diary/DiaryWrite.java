package com.kr.diary;

public class DiaryWrite {
}
